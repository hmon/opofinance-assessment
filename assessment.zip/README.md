# OPOFinance Assessment

## Installation

1. Clone the repository
2. Install dependencies
```bash
pnpm install
```
3. Start the development server
```bash
pnpm dev
```

### Running tests with Vitest
```bash
pnpm test
```
